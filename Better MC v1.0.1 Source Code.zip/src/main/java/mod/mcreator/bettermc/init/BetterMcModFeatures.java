
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package mod.mcreator.bettermc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import mod.mcreator.bettermc.world.features.ores.TitaniumOreFeature;
import mod.mcreator.bettermc.world.features.ores.SteelOreFeature;
import mod.mcreator.bettermc.world.features.ores.SecretOreFeature;
import mod.mcreator.bettermc.world.features.ores.RubyOreFeature;
import mod.mcreator.bettermc.world.features.ores.RadiumOreFeature;
import mod.mcreator.bettermc.world.features.ores.LeadOreFeature;
import mod.mcreator.bettermc.BetterMcMod;

@Mod.EventBusSubscriber
public class BetterMcModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, BetterMcMod.MODID);
	public static final RegistryObject<Feature<?>> STEEL_ORE = REGISTRY.register("steel_ore", SteelOreFeature::feature);
	public static final RegistryObject<Feature<?>> RUBY_ORE = REGISTRY.register("ruby_ore", RubyOreFeature::feature);
	public static final RegistryObject<Feature<?>> RADIUM_ORE = REGISTRY.register("radium_ore", RadiumOreFeature::feature);
	public static final RegistryObject<Feature<?>> LEAD_ORE = REGISTRY.register("lead_ore", LeadOreFeature::feature);
	public static final RegistryObject<Feature<?>> TITANIUM_ORE = REGISTRY.register("titanium_ore", TitaniumOreFeature::feature);
	public static final RegistryObject<Feature<?>> SECRET_ORE = REGISTRY.register("secret_ore", SecretOreFeature::feature);
}
