
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package mod.mcreator.bettermc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import mod.mcreator.bettermc.potion.BedrockEffectMobEffect;
import mod.mcreator.bettermc.BetterMcMod;

public class BetterMcModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, BetterMcMod.MODID);
	public static final RegistryObject<MobEffect> BEDROCK_EFFECT = REGISTRY.register("bedrock_effect", () -> new BedrockEffectMobEffect());
}
