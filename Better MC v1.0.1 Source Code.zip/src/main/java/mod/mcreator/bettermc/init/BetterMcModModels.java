
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package mod.mcreator.bettermc.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import mod.mcreator.bettermc.client.model.Modelarmor_colour_main;
import mod.mcreator.bettermc.client.model.Modelarmor_colour_leggings;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class BetterMcModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelarmor_colour_leggings.LAYER_LOCATION, Modelarmor_colour_leggings::createBodyLayer);
		event.registerLayerDefinition(Modelarmor_colour_main.LAYER_LOCATION, Modelarmor_colour_main::createBodyLayer);
	}
}
