
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package mod.mcreator.bettermc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import mod.mcreator.bettermc.block.TitaniumOreBlock;
import mod.mcreator.bettermc.block.TitaniumBlockBlock;
import mod.mcreator.bettermc.block.TitaniumAlloyBlockBlock;
import mod.mcreator.bettermc.block.SteelOreBlock;
import mod.mcreator.bettermc.block.SteelBlockBlock;
import mod.mcreator.bettermc.block.SecretOreBlock;
import mod.mcreator.bettermc.block.SecretCrystalBlockBlock;
import mod.mcreator.bettermc.block.SecretBlockBlock;
import mod.mcreator.bettermc.block.RubyOreBlock;
import mod.mcreator.bettermc.block.RubyBlockBlock;
import mod.mcreator.bettermc.block.RadiumOreBlock;
import mod.mcreator.bettermc.block.RadiumBlockBlock;
import mod.mcreator.bettermc.block.LeadOreBlock;
import mod.mcreator.bettermc.block.LeadBlockBlock;
import mod.mcreator.bettermc.block.CamphorWoodWoodBlock;
import mod.mcreator.bettermc.block.CamphorWoodPlanksBlock;
import mod.mcreator.bettermc.block.CamphorWoodLogBlock;
import mod.mcreator.bettermc.block.CamphorWoodLeavesBlock;
import mod.mcreator.bettermc.block.CamphorWoodFenceGateBlock;
import mod.mcreator.bettermc.block.CamphorWoodFenceBlock;
import mod.mcreator.bettermc.block.CamphorWoodButtonBlock;
import mod.mcreator.bettermc.block.BedrockBlockBlock;
import mod.mcreator.bettermc.BetterMcMod;

public class BetterMcModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, BetterMcMod.MODID);
	public static final RegistryObject<Block> BEDROCK_BLOCK = REGISTRY.register("bedrock_block", () -> new BedrockBlockBlock());
	public static final RegistryObject<Block> STEEL_ORE = REGISTRY.register("steel_ore", () -> new SteelOreBlock());
	public static final RegistryObject<Block> STEEL_BLOCK = REGISTRY.register("steel_block", () -> new SteelBlockBlock());
	public static final RegistryObject<Block> RUBY_ORE = REGISTRY.register("ruby_ore", () -> new RubyOreBlock());
	public static final RegistryObject<Block> RUBY_BLOCK = REGISTRY.register("ruby_block", () -> new RubyBlockBlock());
	public static final RegistryObject<Block> SECRET_CRYSTAL_BLOCK = REGISTRY.register("secret_crystal_block", () -> new SecretCrystalBlockBlock());
	public static final RegistryObject<Block> RADIUM_ORE = REGISTRY.register("radium_ore", () -> new RadiumOreBlock());
	public static final RegistryObject<Block> RADIUM_BLOCK = REGISTRY.register("radium_block", () -> new RadiumBlockBlock());
	public static final RegistryObject<Block> LEAD_ORE = REGISTRY.register("lead_ore", () -> new LeadOreBlock());
	public static final RegistryObject<Block> LEAD_BLOCK = REGISTRY.register("lead_block", () -> new LeadBlockBlock());
	public static final RegistryObject<Block> TITANIUM_ALLOY_BLOCK = REGISTRY.register("titanium_alloy_block", () -> new TitaniumAlloyBlockBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_WOOD = REGISTRY.register("camphor_wood_wood", () -> new CamphorWoodWoodBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_LOG = REGISTRY.register("camphor_wood_log", () -> new CamphorWoodLogBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_PLANKS = REGISTRY.register("camphor_wood_planks", () -> new CamphorWoodPlanksBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_BUTTON = REGISTRY.register("camphor_wood_button", () -> new CamphorWoodButtonBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_LEAVES = REGISTRY.register("camphor_wood_leaves", () -> new CamphorWoodLeavesBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_FENCE = REGISTRY.register("camphor_wood_fence", () -> new CamphorWoodFenceBlock());
	public static final RegistryObject<Block> CAMPHOR_WOOD_FENCE_GATE = REGISTRY.register("camphor_wood_fence_gate", () -> new CamphorWoodFenceGateBlock());
	public static final RegistryObject<Block> TITANIUM_ORE = REGISTRY.register("titanium_ore", () -> new TitaniumOreBlock());
	public static final RegistryObject<Block> TITANIUM_BLOCK = REGISTRY.register("titanium_block", () -> new TitaniumBlockBlock());
	public static final RegistryObject<Block> SECRET_ORE = REGISTRY.register("secret_ore", () -> new SecretOreBlock());
	public static final RegistryObject<Block> SECRET_BLOCK = REGISTRY.register("secret_block", () -> new SecretBlockBlock());
}
