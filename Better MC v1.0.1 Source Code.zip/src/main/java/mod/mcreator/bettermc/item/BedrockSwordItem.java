
package mod.mcreator.bettermc.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.entity.LivingEntity;

import mod.mcreator.bettermc.procedures.BedrockSwordDangShiTiBeiGongJuJiZhongShiProcedure;
import mod.mcreator.bettermc.init.BetterMcModItems;

public class BedrockSwordItem extends SwordItem {
	public BedrockSwordItem() {
		super(new Tier() {
			public int getUses() {
				return 0;
			}

			public float getSpeed() {
				return 99f;
			}

			public float getAttackDamageBonus() {
				return 58f;
			}

			public int getLevel() {
				return 100;
			}

			public int getEnchantmentValue() {
				return 140;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(BetterMcModItems.BEDROCK_INGOT.get()));
			}
		}, 3, -4f, new Item.Properties().tab(CreativeModeTab.TAB_COMBAT).fireResistant());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		BedrockSwordDangShiTiBeiGongJuJiZhongShiProcedure.execute(entity);
		return retval;
	}
}
