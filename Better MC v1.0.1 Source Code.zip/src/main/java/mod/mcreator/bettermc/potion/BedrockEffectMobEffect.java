
package mod.mcreator.bettermc.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import mod.mcreator.bettermc.procedures.BedrockEffectZaiXiaoGuoChiXuShiMeiKeFaShengProcedure;
import mod.mcreator.bettermc.procedures.BedrockEffectDangYaoShuiXiaoGuoKaiShiYingYongShiProcedure;

public class BedrockEffectMobEffect extends MobEffect {
	public BedrockEffectMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -11513776);
	}

	@Override
	public String getDescriptionId() {
		return "effect.better_mc.bedrock_effect";
	}

	@Override
	public boolean isInstantenous() {
		return true;
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		BedrockEffectDangYaoShuiXiaoGuoKaiShiYingYongShiProcedure.execute(entity);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		BedrockEffectZaiXiaoGuoChiXuShiMeiKeFaShengProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
