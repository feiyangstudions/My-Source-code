
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package mod.mcreator.bettermc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import mod.mcreator.bettermc.BetterMcMod;

public class BetterMcModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, BetterMcMod.MODID);
	public static final RegistryObject<Potion> BEDROCK_MIXTURES = REGISTRY.register("bedrock_mixtures", () -> new Potion(new MobEffectInstance(BetterMcModMobEffects.BEDROCK_EFFECT.get(), 1200, 0, false, false)));
}
