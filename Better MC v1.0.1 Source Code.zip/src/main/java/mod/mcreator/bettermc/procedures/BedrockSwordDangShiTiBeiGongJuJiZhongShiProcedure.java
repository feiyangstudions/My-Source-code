package mod.mcreator.bettermc.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import mod.mcreator.bettermc.init.BetterMcModItems;

public class BedrockSwordDangShiTiBeiGongJuJiZhongShiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(BetterMcModItems.BEDROCK_SWORD.get())) : false) != true) {
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(0);
		}
	}
}
